#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This program identifies a leap year


def main():
    # this function uses a try statement

    # input
    print("Will it be a leap year?")

    try:
        year = int(input("Enter a year: "))
        print("")
        # process & output
        if (year % 4) == 0:
            if (year % 100) == 0:
                if (year % 400) == 0:
                    print("{0} is a leap year".format(year))
                else:
                    print("{0} isn't a leap year".format(year))
            else:
                print("{0} is a leap year".format(year))
        else:
            print("{0} isn't a leap year".format(year))

    except ValueError:
        print("")
        print("ERROR: THAT IS NOT A VALID INPUT")


if __name__ == "__main__":
    main()
